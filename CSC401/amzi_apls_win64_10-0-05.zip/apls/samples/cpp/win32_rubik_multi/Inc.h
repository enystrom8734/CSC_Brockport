// Includes

#include "tchar.h"
#include "iostream.h"
#include "stdio.h"
#include "Lstring.h"
#include "Amzi.h"
#include "Rubik.h"
#include "CubeMT.h"
#include "CubeWnd.h"
#include "CubeThread.h"
#include "MainFrm.h"
